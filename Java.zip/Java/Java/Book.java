public class Book
{
	private String bookName;
	private String bookAuthor;
	private String bookId;
	private String bookType;
	private int bookCopy;
	private static int uniqueBookCounter = 0;
	
	public Book()
	{
	uniqueBookCounter++;
	}
	
	public Book()
	{
		System.out.println("E-Constructor");
	}
	public Book(String bookName,String bookAuthor,String bookid,String bookType,int bookCopy)
	{
		System.out.println("P-Constructor");
		setbookName(bookName);
		setbookAuthor(bookAuthor);
		setbookId(bookId);
		setbookType(bookType);
		setbookCopy(bookCopy);
	}
	public void setbookName(String bookName)
	{
		this.bookName=bookName;
	}
	public String getbookName()
	{
		return bookName;
	}
	public void setbookAuthor(String bookAuthor)
	{
		this.bookAuthor=bookAuthor;
	}
	public String getbookAuthor()
	{
		return bookAuthor;
	}
	public void setbookId(String bookId)
	{
		this.bookId=bookId;
	}
	public String getbookId()
	{
		return bookId;
	}
	public void setbookType(String bookType)
	{
		this.bookType=bookType;
	}
	public String getbookType()
	{
		return bookType;
	}
	public void setbookCopy(int bookCopy)
	{
		this.bookCopy=bookCopy;
	}
	public int getbookCopy()
	{
		return bookCopy;
	}
	public void showDetails()
	{
		System.out.println("Book Name  : "+bookName);
		System.out.println("Book Author: "+bookAuthor);
		System.out.println("Book ID    : "+bookId);
		System.out.println("Book Type  : "+bookType);
		System.out.println("Book Copy  : "+bookCopy);
	}
	public void addBookCopy(int x)
	{
		bookCopy+=x;
		System.out.println("Book copy after add: "+bookCopy);
	}
	public static void main(String args[])
	{
		Book b1 = new Book("Book 1","Author 1","23-***-3","Comedy",25);
		Book b2 = new Book("Book 2","Author 2","23-***-2","Love",20);
		Book b2 = new Book("Book 3","Author 3","23-***-1","Comedy",15);
		Book b2 = new Book("Book 4","Author","24-***-1","Love",10);
		
		b1.setbookName("Marriage");
		b1.setbookAuthor("Rahman");
		b1.setbookId("100");
		b1.setbookCopy(500);
		b1.setbookType("Love");
		b1.showDetails();
		b2.showDetails();
		b2.addBookCopy(2);
		b2.showDetails();
	}
}  