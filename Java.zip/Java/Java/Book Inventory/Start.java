import Entity.Book;
import EntityList.BookList;
import GUI.LoginPage;
public class Start{
	public static void main(String []args){
		LoginPage page = new LoginPage();
	}
}