package Files;
import java.io.*;
import java.util.Scanner;
import Entity.*;
import EntityList.*;

public class FileIO{
	public static boolean checkUser(String userName,String userPass){
		boolean flag = false;
		try{
			Scanner fsc = new Scanner(new File("./Files/users.txt"));
			while(fsc.hasNextLine()){
				String line = fsc.nextLine();
				String data[] = line.split(";");
				if(userName.equals(data[1]) && userPass.equals(data[2])){
					flag = true;
					break;
				}
			}
			fsc.close();
		}
		catch(Exception ex){
			System.out.println("Cannot Read File");
		}
		return flag;
	}
	
	public static void loadBookFromFile(BookList bookList){
		try{
			Scanner fsc = new Scanner(new File("./Files/books.txt"));
			while(fsc.hasNextLine()){
				String line = fsc.nextLine();
				String data[] = line.split(";");
				Book tempb = new Book(data[0],
									data[1],
									data[2],
									data[3],
									Integer.parseInt(data[4]));
					bookList.insert(tempb);
			}
			fsc.close();
		}
		catch(Exception ex){
			System.out.println("Cannot Read File");
		}
	}
	
	public static void writeBookInFile(Book b){
		try{
			FileWriter fw = new FileWriter(new File("./Files/books.txt"),true);
			String line = b.getBookId()+";"+b.getBookName()+";"+b.getBookAuthor()+";"+b.getBookType()+";"+b.getBookCopy()+"\n";
			fw.write(line);
			fw.flush();
			fw.close();
		}
		catch(Exception ex){
			System.out.println("File Not Found");
		}
	}
	
	
}