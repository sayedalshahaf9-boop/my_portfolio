import java.io.*;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Start {
    // Entity/tPackage class definition
    static class tPackage {
        private String packageId;
        private String packageName;
        private String packageDestination;
        private String packageType;
        private int amountOfDay;
        private double price;
        private String desciption;
        private static int packageCounter = 0;

        public tPackage() {}

        public tPackage(String packageId, String packageName, String packageDestination, String packageType, int amountOfDay, double price, String desciption) {
            this.packageId = packageId;
            this.packageName = packageName;
            this.packageDestination = packageDestination;
            this.packageType = packageType;
            this.amountOfDay = amountOfDay;
            this.price = price;
            this.desciption = desciption;
            packageCounter++;
        }

        // Setter and getter methods
        public String getPackageId() { return packageId; }
        public String getPackageName() { return packageName; }
        public String getPackageDestination() { return packageDestination; }
        public String getPackageType() { return packageType; }
        public int getAmountOfDay() { return amountOfDay; }
        public double getPrice() { return price; }
        public String getDescription() { return desciption; }

        public void setAmountOfDay(int amountOfDay) { this.amountOfDay = amountOfDay; }

        // Show package info
        public void showPackageInfo() {
            System.out.println("Package Id : " + packageId);
            System.out.println("Package Name : " + packageName);
            System.out.println("Package Destination : " + packageDestination);
            System.out.println("Package Type : " + packageType);
            System.out.println("Amount of Days : " + amountOfDay);
            System.out.println("Package Price : " + price + " BDT");
            System.out.println("Package Description : " + desciption);
        }

        // Static method to display total number of packages
        public static void totalNumberOfPackages() {
            System.out.println("Total Number Of Packages : " + packageCounter);
        }
    }

    // EntityList/tPackageList class definition
    static class tPackageList {
        private tPackage[] packages;

        public tPackageList() {
            packages = new tPackage[10];
        }

        public tPackageList(int size) {
            packages = new tPackage[size];
        }

        public void insert(tPackage p) {
            boolean flag = false;
            for (int i = 0; i < packages.length; i++) {
                if (packages[i] == null) {
                    packages[i] = p;
                    flag = true;
                    break;
                }
            }
            if (flag) {
                System.out.println("Successfully Inserted.");
            } else {
                System.out.println("Insertion Failed!");
            }
        }

        public tPackage getById(String id) {
            tPackage p = null;
            for (int i = 0; i < packages.length; i++) {
                if (packages[i] != null && packages[i].getPackageId().equals(id)) {
                    p = packages[i];
                    System.out.println("Package Found.");
                    break;
                }
            }
            if (p == null) {
                System.out.println("No Package with This Id!");
            }
            return p;
        }

        public void removeById(String id) {
            boolean flag = false;
            for (int i = 0; i < packages.length; i++) {
                if (packages[i] != null && packages[i].getPackageId().equals(id)) {
                    packages[i] = null;
                    flag = true;
                    break;
                }
            }
            if (flag) {
                System.out.println("Package Removed.");
            } else {
                System.out.println("No Package with This Id!");
            }
        }

        public void showAll() {
            for (int i = 0; i < packages.length; i++) {
                if (packages[i] != null) {
                    System.out.println("--------------");
                    packages[i].showPackageInfo();
                    System.out.println("--------------");
                }
            }
        }

        public void showByType(String type) {
            for (int i = 0; i < packages.length; i++) {
                if (packages[i] != null && packages[i].getPackageType().equals(type)) {
                    System.out.println("--------------");
                    packages[i].showPackageInfo();
                    System.out.println("--------------");
                }
            }
        }
    }

    // FileIO class definition
    static class FileIO {
        public static boolean checkUser(String userName, String userPass) {
            // Simulate always returning true for any credentials
            return true;
        }

        public static void loadPackageFromFile(tPackageList tPackageList) {
            try {
                Scanner fsc = new Scanner(new File("./Files/packages.txt"));
                while (fsc.hasNextLine()) {
                    String line = fsc.nextLine();
                    String[] data = line.split(";");
                    tPackage tempp = new tPackage(data[0], data[1], data[2], data[3], Integer.parseInt(data[4]), Double.parseDouble(data[5]), data[6]);
                    tPackageList.insert(tempp);
                }
                fsc.close();
            } catch (Exception ex) {
                System.out.println("Cannot Read File");
            }
        }

        public static void writePackageInFile(tPackage p) {
            try {
                FileWriter fw = new FileWriter(new File("./Files/packages.txt"), true);
                String line = p.getPackageId() + ";" + p.getPackageName() + ";" + p.getPackageDestination() + ";" + p.getPackageType() + ";" + p.getAmountOfDay() + ";" + p.getPrice() + ";" + p.getDescription() + "\n";
                fw.write(line);
                fw.flush();
                fw.close();
            } catch (Exception ex) {
                System.out.println("File Not Found");
            }
        }
    }

    // LoginPage class definition
    static class LoginPage extends JFrame implements ActionListener {
        Font font20 = new Font("Cambria", Font.PLAIN, 20);
        Font font25 = new Font("Cambria", Font.BOLD, 25);
        Font font30 = new Font("Cambria", Font.PLAIN, 30);

        JLabel userLabel, passLabel;
        JTextField userTextField;
        JPasswordField userPassField;
        JButton loginBtn, registerBtn;

        public LoginPage() {
            super("Login Page");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setSize(400, 400);
            this.setLocation(200, 100);
            this.setLayout(null);
            this.getContentPane().setBackground(new Color(44, 62, 80));

            userLabel = new JLabel("User ID : ");
            userLabel.setBounds(50, 50, 100, 40);
            userLabel.setFont(font20);
            userLabel.setForeground(new Color(236, 240, 241));
            this.add(userLabel);

            passLabel = new JLabel("Password : ");
            passLabel.setBounds(50, 100, 100, 40);
            passLabel.setFont(font20);
            passLabel.setForeground(new Color(236, 240, 241));
            this.add(passLabel);

            userTextField = new JTextField();
            userTextField.setBounds(160, 50, 200, 40);
            userTextField.setFont(font20);
            this.add(userTextField);

            userPassField = new JPasswordField();
            userPassField.setBounds(160, 100, 200, 40);
            userPassField.setFont(font20);
            this.add(userPassField);

            loginBtn = new JButton("Login");
            loginBtn.setBounds(50, 160, 140, 50);
            loginBtn.setFont(font25);
            loginBtn.setBackground(new Color(30, 132, 73));
            loginBtn.setForeground(new Color(236, 240, 241));
            loginBtn.addActionListener(this);
            this.add(loginBtn);

            registerBtn = new JButton("Register");
            registerBtn.setBounds(220, 160, 140, 50);
            registerBtn.setFont(font25);
            registerBtn.setBackground(new Color(27, 163, 156));
            registerBtn.setForeground(new Color(236, 240, 241));
            registerBtn.addActionListener(this);
            this.add(registerBtn);

            this.setVisible(true);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == loginBtn) {
                String userId = userTextField.getText();
                String pass = String.valueOf(userPassField.getPassword());
                boolean isValid = FileIO.checkUser(userId, pass);
                if (isValid) {
                    JOptionPane.showMessageDialog(null, "Login Successful");
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Credentials");
                }
            } else if (e.getSource() == registerBtn) {
                JOptionPane.showMessageDialog(null, "Registration Functionality Coming Soon");
            }
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}
